<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>ToDo App</title>
    <style>
        /* Estilos básicos para que no se vea roto, pero sí simple */
        body { font-family: sans-serif; padding: 20px; }
        .mensaje { color: green; font-weight: bold; padding: 10px; border: 1px solid green; margin-bottom: 10px; }
        .caja-categoria { border: 1px solid #000; padding: 10px; margin-bottom: 20px; background: #f9f9f9; }
        .tarea { border-bottom: 1px solid #ccc; padding: 5px 0; display: flex; justify-content: space-between; }
        button { cursor: pointer; }
    </style>
</head>
<body>
    <h1>Gestor de Tareas</h1>

    <?php if(session('success')): ?>
        <div class="mensaje"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div style="margin-bottom: 20px;">
        <form action="<?php echo e(route('categories.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <label>Nueva Categoría:</label>
            <input type="text" name="name" required placeholder="Nombre categoría...">
            <button type="submit">Agregar</button>
        </form>
    </div>

    <hr>

    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="caja-categoria">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <h2 style="margin: 0; color: #333;"><?php echo e($category->name); ?></h2>
                
                <form action="<?php echo e(route('categories.destroy', $category)); ?>" method="POST" onsubmit="return confirm('¿Seguro? Se borrarán las tareas dentro.');">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button style="color: red;">Eliminar Categoría</button>
                </form>
            </div>

            <ul>
                <?php $__currentLoopData = $category->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="tarea">
                        <span><?php echo e($task->title); ?></span>
                        <div>
                            <a href="<?php echo e(route('tasks.edit', $task)); ?>">[Editar]</a>
                            
                            <form action="<?php echo e(route('tasks.destroy', $task)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit">X</button>
                            </form>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <div style="margin-top: 10px;">
                <form action="<?php echo e(route('tasks.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="category_id" value="<?php echo e($category->id); ?>">
                    <input type="text" name="title" required placeholder="Nueva tarea aqui...">
                    <button type="submit">+</button>
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH /workspaces/laravel-todolist2/resources/views/categories/index.blade.php ENDPATH**/ ?>